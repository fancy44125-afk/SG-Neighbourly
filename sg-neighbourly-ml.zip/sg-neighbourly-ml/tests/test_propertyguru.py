import pandas as pd
from shapely.geometry import box

import src.data_pipeline as pipeline


def test_propertyguru_filters_rooms_and_deduplicates(tmp_path, monkeypatch):
    monkeypatch.setattr(pipeline, "RAW", tmp_path)
    pd.DataFrame([
        {"listing_id": "1", "property_type": "condo", "monthly_rent": 4000,
         "latitude": 1.30, "longitude": 103.80, "whole_unit": True,
         "listing_url": "https://example/1", "collected_at": "2026-10-19"},
        {"listing_id": "1", "property_type": "condo", "monthly_rent": 4200,
         "latitude": 1.30, "longitude": 103.80, "whole_unit": True,
         "listing_url": "https://example/1", "collected_at": "2026-10-20"},
        {"listing_id": "2", "property_type": "condo", "monthly_rent": 1200,
         "latitude": 1.30, "longitude": 103.80, "whole_unit": False,
         "listing_url": "https://example/2", "collected_at": "2026-10-20"},
    ]).to_csv(tmp_path / "propertyguru_listings.csv", index=False)
    areas = pd.DataFrame([{"planning_area": "Example", "centre_lat": 1.30, "centre_lon": 103.80}])
    result = pipeline.propertyguru_asking_rents(
        [box(103.79, 1.29, 103.81, 1.31)], areas
    )
    assert result.loc[0, "propertyguru_condo_asking_rent_mean"] == 4200
    assert result.loc[0, "propertyguru_condo_listing_count"] == 1
