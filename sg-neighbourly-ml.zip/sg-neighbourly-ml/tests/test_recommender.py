import pandas as pd

from src.recommender import AreaRecommender, RecommendationRequest


def test_budget_filter_and_selected_features_only(tmp_path):
    data = pd.DataFrame({
        "planning_area": ["A", "B", "C"],
        "hdb_monthly_rent": [2500, 3100, 2800],
        "childcare_distance_km": [0.4, 0.2, 0.7],
        "healthcare_distance_km": [0.8, 0.5, 0.3],
        "mrt_stations_distance_km": [0.3, 0.6, 0.4],
    })
    path = tmp_path / "features.csv"
    data.to_csv(path, index=False)
    result = AreaRecommender(path).recommend(RecommendationRequest(
        "hdb", 3000, ("childcare", "healthcare", "mrt_stations"), 3
    ))
    assert set(result.planning_area) == {"A", "C"}
    assert "B" not in set(result.planning_area)
    assert result["rank"].tolist() == list(range(1, len(result) + 1))


def test_too_low_rent_returns_no_results(tmp_path):
    path = tmp_path / "features.csv"
    pd.DataFrame({"planning_area": ["A"], "house_monthly_rent": [5000], "parks_distance_km": [0.4]}).to_csv(path, index=False)
    result = AreaRecommender(path).recommend(RecommendationRequest("house", 1000, ("parks",)))
    assert result.empty
