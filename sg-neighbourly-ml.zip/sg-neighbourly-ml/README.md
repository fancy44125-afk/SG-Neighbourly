# SG Neighbourly: Python recommendation model

This repository contains the data preparation and equal-weight K-Nearest Neighbours recommendation code used for the SG Neighbourly rental matcher.

## Included

- `src/recommender.py`: budget filtering, feature normalisation, KNN ranking and match percentages.
- `scripts/build_complete_dataset.py`: assembles the supplied rent, amenity, transport and wheelchair-accessibility evidence.
- `data/processed/planning_area_complete.csv`: final 42-area dataset used by the model and demo.
- `data/raw/singapore_nearest_amenities.xlsx`: supplied amenities workbook.
- `recommend.py`: command-line demonstration.
- `tests/`: automated checks for filtering and ranking behaviour.

Only areas with evidence for the chosen rental property type are eligible: 26 for HDB, 42 for condominium and 31 for landed house rentals.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
pytest
```

On Windows, activate the environment with `.venv\\Scripts\\activate`.

## Example

```bash
python recommend.py --housing hdb --budget 3500 \\
  --criteria schools public_transport groceries healthcare parks
```

Available criteria are `schools`, `cbd`, `public_transport`, `groceries`, `wheelchair_accessibility`, `beaches`, `healthcare` and `parks`.

## Method

The model applies the property-type and maximum-rent requirements as hard filters. Areas missing any selected criterion are removed. Each selected feature is min-max normalised using the available population; shorter distances score higher, while higher wheelchair-accessibility values score higher. A Manhattan-distance nearest-neighbour model finds the three profiles closest to an ideal vector, with every selected feature weighted equally.

The displayed match percentage is the arithmetic mean of the selected 0-100 suitability scores. It is a transparent comparative score, not a predicted probability.

CBD distance is measured in a straight line from each planning-area centre to Raffles Place MRT at latitude 1.28393 and longitude 103.85146. Other displayed distances are also straight-line area-centre comparisons rather than walking, driving or transit travel times.

## Rebuild the combined dataset

```bash
python scripts/build_complete_dataset.py
```

The build script reads the included raw amenities workbook and existing processed base table, then updates `data/processed/planning_area_complete.csv` and generates `data/processed/planning_area_features.json`.
