"""Build the 42-area website dataset from the supplied workbook and rent tables."""
from __future__ import annotations

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
AMENITIES = ROOT / "data/raw/singapore_nearest_amenities.xlsx"
BASE = ROOT / "data/processed/planning_area_features.csv"
OUTPUT = ROOT / "data/processed/planning_area_complete.csv"

CONDO = """Ang Mo Kio|4000
Bedok|4000
Bishan|4250
Boon Lay|4100
Bukit Batok|3800
Bukit Merah|5200
Bukit Panjang|4000
Bukit Timah|4800
Changi|3450
Choa Chu Kang|3900
Clementi|4350
Downtown Core|5000
Geylang|3800
Hougang|3500
Jurong East|4550
Jurong West|4600
Kallang|4250
Mandai|4000
Marine Parade|5200
Museum|5200
Newton|7400
Novena|4300
Orchard|7700
Outram|4500
Pasir Ris|3500
Pioneer|3950
Punggol|3700
Queenstown|4300
River Valley|6300
Rochor|4200
Seletar|3200
Sembawang|3800
Sengkang|3500
Serangoon|3600
Singapore River|6300
Southern Islands|10800
Tampines|3600
Tanglin|6000
Tengah|4800
Toa Payoh|4200
Woodlands|4000
Yishun|3650"""

HOUSE = """Ang Mo Kio|6800
Bedok|7500
Bishan|7800
Bukit Batok|5500
Bukit Merah|8200
Bukit Panjang|5200
Bukit Timah|13500
Choa Chu Kang|5000
Clementi|7500
Geylang|6500
Hougang|6200
Jurong East|5200
Jurong West|4800
Kallang|6200
Marine Parade|8800
Newton|9800
Novena|9200
Pasir Ris|6200
Punggol|5200
Queenstown|8500
River Valley|9500
Seletar|6800
Sembawang|5500
Sengkang|5800
Serangoon|7200
Southern Islands|25000
Tampines|6200
Tanglin|16000
Toa Payoh|7200
Woodlands|5200
Yishun|5500"""

TRANSPORT = """Ang Mo Kio|Bus 55199|0.089
Bedok|Bus 84039|0.076
Bishan|Bus 53141|0.127
Boon Lay|Bus 22051|0.104
Bukit Batok|Bus 43569|0.266
Bukit Merah|Bus 14031|0.084
Bukit Panjang|Bus 43961|0.221
Bukit Timah|Bus 42021|0.339
Changi|Changi Airport MRT, Exit A|1.162
Choa Chu Kang|Bus 44009|0.160
Clementi|Bus 17059|0.128
Downtown Core|Bus 03011|0.265
Geylang|Bus 81221|0.144
Hougang|Bus 63059|0.082
Jurong East|Bus 20241|0.194
Jurong West|Bus 22481|0.118
Kallang|Bus 80011|0.181
Mandai|Bus 47539|0.808
Marine Parade|Bus 82051|0.141
Museum|Bus 08041|0.272
Newton|Bus 40179|0.326
Novena|Bus 51099|0.150
Orchard|Bus 09048|0.066
Outram|Bus 05039|0.054
Pasir Ris|Bus 77109|0.212
Pioneer|Bus 24299|0.156
Punggol|Bus 65309|0.112
Queenstown|Bus 15129|0.062
River Valley|Great World MRT, Exit 5|0.178
Rochor|Rochor MRT, Exit B|0.022
Seletar|Bus 68239|0.477
Sembawang|Bus 58409|0.090
Sengkang|Bus 67361|0.078
Serangoon|Bus 66261|0.161
Singapore River|Bus 06169|0.159
Southern Islands|Bus 14529|1.985
Tampines|Bus 96149|0.122
Tanglin|Napier MRT, Exit 1|0.264
Tengah|Bus 40439|0.396
Toa Payoh|Bus 52399|0.147
Woodlands|Bus 46279|0.103
Yishun|Bus 59481|0.083"""

TIERS = {
    1: "Punggol,Sengkang,Downtown Core,Orchard,Jurong East,Tampines,Bishan,Woodlands,Choa Chu Kang,Bukit Batok",
    2: "Bedok,Ang Mo Kio,Toa Payoh,Bukit Panjang,Jurong West,Pasir Ris,Hougang,Sembawang,Novena,Queenstown,Yishun,Clementi,Boon Lay",
    3: "Bukit Merah,Rochor,Outram,Kallang,Geylang,Marine Parade,Serangoon,Bukit Timah,Museum,Newton,Singapore River,River Valley,Tanglin",
    4: "Pioneer,Changi,Seletar,Mandai,Southern Islands,Tengah",
}


def parse_values(text: str, columns: list[str]) -> pd.DataFrame:
    return pd.DataFrame([line.split("|") for line in text.splitlines()], columns=columns)


def main() -> None:
    base = pd.read_csv(BASE)
    keep = ["planning_area", "centre_lat", "centre_lon", "cbd_distance_km", "hdb_monthly_rent", "hdb_contract_count"]
    base = base[keep]

    source = pd.read_excel(AMENITIES, sheet_name="Distances and sources")
    category_names = {
        "Grocery": "groceries",
        "Primary school": "schools",
        "Hospital or clinic": "healthcare",
        "Park": "parks",
        "Beach": "beaches",
    }
    amenity_parts = []
    for source_name, output_name in category_names.items():
        part = source[source["Category"] == source_name][["Planning area", "POI name", "Distance km"]].copy()
        part.columns = ["planning_area", f"{output_name}_name", f"{output_name}_distance_km"]
        amenity_parts.append(part)
    amenities = amenity_parts[0]
    for part in amenity_parts[1:]:
        amenities = amenities.merge(part, on="planning_area", how="outer", validate="one_to_one")

    condo = parse_values(CONDO, ["planning_area", "condo_monthly_rent"])
    house = parse_values(HOUSE, ["planning_area", "house_monthly_rent"])
    transport = parse_values(TRANSPORT, ["planning_area", "public_transport_name", "public_transport_distance_km"])
    for frame, column in [(condo, "condo_monthly_rent"), (house, "house_monthly_rent"), (transport, "public_transport_distance_km")]:
        frame[column] = pd.to_numeric(frame[column])

    tier_rows = []
    for tier, names in TIERS.items():
        for name in names.split(","):
            tier_rows.append({
                "planning_area": name,
                "wheelchair_accessibility_tier": tier,
                "wheelchair_accessibility_score": {1: 1.0, 2: 0.75, 3: 0.5, 4: 0.25}[tier],
            })
    wheelchair = pd.DataFrame(tier_rows)

    result = base.merge(amenities, on="planning_area", how="inner", validate="one_to_one")
    for frame in [condo, house, transport, wheelchair]:
        result = result.merge(frame, on="planning_area", how="left", validate="one_to_one")
    result = result.sort_values("planning_area").reset_index(drop=True)
    if len(result) != 42:
        raise ValueError(f"Expected 42 retained planning areas, got {len(result)}")
    assert result["condo_monthly_rent"].notna().sum() == 42
    assert result["house_monthly_rent"].notna().sum() == 31
    assert result["hdb_monthly_rent"].notna().sum() == 26
    assert result["public_transport_distance_km"].notna().sum() == 42
    assert result["wheelchair_accessibility_score"].notna().sum() == 42
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT, index=False)
    print(result.shape)
    print(result.notna().sum().to_string())


if __name__ == "__main__":
    main()
