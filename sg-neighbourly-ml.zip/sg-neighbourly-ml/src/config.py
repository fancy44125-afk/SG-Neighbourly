from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"

BOUNDARY_DATASET = "d_4765db0e87b9c86336792efe8a1f7a66"
HDB_RENT_DATASET = "d_c9f57187485a850908655db0e8cfe651"

# Used only for a common, transparent CBD reference point.
CBD = {"name": "Raffles Place MRT", "lat": 1.28393, "lon": 103.85146}

# OSM tags are a reproducible fallback. A source field in every POI row makes
# it impossible to confuse these with verified OneMap records.
OSM_FILTERS = {
    "schools": [('amenity', 'school'), ('amenity', 'college'), ('amenity', 'university')],
    "childcare": [('amenity', 'kindergarten'), ('amenity', 'childcare')],
    "tuition_centres": [('office', 'educational_institution'), ('amenity', 'prep_school')],
    "healthcare": [('amenity', 'clinic'), ('amenity', 'doctors'), ('amenity', 'hospital')],
    "supermarkets": [('shop', 'supermarket')],
    "parks": [('leisure', 'park'), ('leisure', 'nature_reserve')],
    "mrt_stations": [('railway', 'station'), ('station', 'subway')],
    "bus_stations": [('highway', 'bus_stop'), ('amenity', 'bus_station')],
    "elderly_facilities": [('social_facility:for', 'senior'), ('amenity', 'nursing_home')],
    "community_centres": [('amenity', 'community_centre')],
    "libraries": [('amenity', 'library')],
    "sports_facilities": [('leisure', 'sports_centre'), ('leisure', 'stadium'), ('leisure', 'pitch')],
    "malls": [('shop', 'mall')],
    "entertainment": [('tourism', 'attraction'), ('leisure', 'amusement_arcade'), ('natural', 'beach')],
    "hawker_centres": [('amenity', 'food_court'), ('amenity', 'marketplace')],
}

