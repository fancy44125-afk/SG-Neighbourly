"""Singapore planning-area recommendation package."""

