from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import MinMaxScaler

DISTANCE_SUFFIX = "_distance_km"


@dataclass(frozen=True)
class RecommendationRequest:
    housing_type: str  # hdb, condo, or house
    maximum_monthly_rent: float
    criteria: tuple[str, ...]
    top_n: int = 3


class AreaRecommender:
    def __init__(self, csv_path: str | Path):
        self.data = pd.read_csv(csv_path)

    def recommend(self, request: RecommendationRequest) -> pd.DataFrame:
        price_column = f"{request.housing_type}_monthly_rent"
        if price_column not in self.data:
            raise ValueError(f"Dataset has no verified rental evidence for {request.housing_type}")
        feature_columns = []
        for criterion in request.criteria:
            if criterion == "cbd":
                feature_columns.append("cbd_distance_km")
            elif criterion == "wheelchair_accessibility":
                feature_columns.append("wheelchair_accessibility_score")
            else:
                feature_columns.append(f"{criterion}{DISTANCE_SUFFIX}")
        missing_columns = sorted(set(feature_columns) - set(self.data.columns))
        if missing_columns:
            raise ValueError(f"Dataset does not contain criteria: {missing_columns}")

        population = self.data[self.data[price_column].notna()].dropna(subset=feature_columns).copy()
        if population.empty:
            return population
        minimum_rent = population[price_column].min()
        if request.maximum_monthly_rent < minimum_rent:
            return population.iloc[0:0].copy()
        eligible_mask = population[price_column] <= request.maximum_monthly_rent
        eligible = population[eligible_mask].copy()
        if eligible.empty:
            return eligible

        # Scale only selected features. Equal Euclidean weighting after scaling
        # means unselected factors have exactly zero influence.
        scaler = MinMaxScaler()
        population_scaled = scaler.fit_transform(population[feature_columns])
        scaled = population_scaled[eligible_mask.to_numpy()]
        ideal = np.array([[
            1.0 if column == "wheelchair_accessibility_score" else 0.0
            for column in feature_columns
        ]])
        # Manhattan distance makes the KNN ordering identical to the displayed
        # equal-weight average suitability score, avoiding contradictory ranks.
        model = NearestNeighbors(n_neighbors=min(request.top_n, len(eligible)), metric="manhattan")
        model.fit(scaled)
        distances, indices = model.kneighbors(ideal)

        result = eligible.iloc[indices[0]].copy()
        result["knn_distance"] = distances[0]
        # A clear 0–100 display score, separate from KNN ranking.
        selected_scores = np.column_stack([
            scaled[indices[0], i] if column == "wheelchair_accessibility_score"
            else 1 - scaled[indices[0], i]
            for i, column in enumerate(feature_columns)
        ])
        result["match_percent"] = selected_scores.mean(axis=1) * 100
        for i, column in enumerate(feature_columns):
            result[f"score_{column}"] = selected_scores[:, i] * 100
        result["rank"] = range(1, len(result) + 1)
        columns = ["rank", "planning_area", price_column, "match_percent", "knn_distance"]
        columns += feature_columns + [f"score_{c}" for c in feature_columns]
        return result[columns].reset_index(drop=True)
