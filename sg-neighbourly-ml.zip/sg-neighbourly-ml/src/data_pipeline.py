from __future__ import annotations

import argparse
import json
import os
import time
from datetime import date
from pathlib import Path

import numpy as np
import pandas as pd
import requests
from pyproj import Transformer
from shapely.geometry import Point, shape
from shapely.ops import transform
from shapely.strtree import STRtree

from .config import BOUNDARY_DATASET, CBD, HDB_RENT_DATASET, OSM_FILTERS, PROCESSED, RAW

SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "sg-planning-area-recommender/1.0 (research project)"})


def _get(url: str, **kwargs) -> requests.Response:
    response = SESSION.get(url, timeout=120, **kwargs)
    response.raise_for_status()
    return response


def download_dataset(dataset_id: str, target: Path) -> Path:
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.stat().st_size:
        return target
    url = f"https://api-open.data.gov.sg/v1/public/api/datasets/{dataset_id}/poll-download"
    for attempt in range(5):
        response = SESSION.get(url, timeout=120, headers={"x-api-key": os.getenv("DATA_GOV_SG_API_KEY", "")})
        if response.status_code != 429:
            response.raise_for_status()
            break
        time.sleep(2 ** attempt)
    else:
        raise RuntimeError("data.gov.sg rate limit persisted after retries")
    metadata = response.json()
    if metadata.get("code") != 0:
        raise RuntimeError(metadata)
    target.write_bytes(_get(metadata["data"]["url"]).content)
    return target


def planning_areas(boundary_file: Path) -> tuple[pd.DataFrame, list]:
    payload = json.loads(boundary_file.read_text())
    to_m = Transformer.from_crs(4326, 3414, always_xy=True).transform
    to_ll = Transformer.from_crs(3414, 4326, always_xy=True).transform
    records = []
    for feature in payload["features"]:
        geom = shape(feature["geometry"])
        geom_m = transform(to_m, geom)
        centre = transform(to_ll, geom_m.centroid)
        name = feature["properties"]["PLN_AREA_N"].title()
        records.append(({"planning_area": name, "centre_lat": centre.y, "centre_lon": centre.x}, geom))
    records.sort(key=lambda item: item[0]["planning_area"])
    result = pd.DataFrame([item[0] for item in records]).reset_index(drop=True)
    polygons = [item[1] for item in records]
    if len(result) != 55:
        raise ValueError(f"Expected 55 planning areas, got {len(result)}")
    return result, polygons


def fetch_datastore(dataset_id: str) -> pd.DataFrame:
    rows, offset, limit = [], 0, 10000
    while True:
        result = _get(
            "https://data.gov.sg/api/action/datastore_search",
            params={"resource_id": dataset_id, "limit": limit, "offset": offset},
        ).json()["result"]
        rows.extend(result["records"])
        offset += len(result["records"])
        if offset >= result["total"] or not result["records"]:
            return pd.DataFrame(rows)


def hdb_rents(months: int = 12) -> pd.DataFrame:
    # The full signed CSV download is considerably faster and more reliable than
    # paginating over 200k+ datastore records.
    csv_path = download_dataset(HDB_RENT_DATASET, RAW / "hdb_rents.csv")
    df = pd.read_csv(csv_path)
    df["rent_approval_date"] = pd.to_datetime(df["rent_approval_date"])
    df["monthly_rent"] = pd.to_numeric(df["monthly_rent"], errors="coerce")
    cutoff = df["rent_approval_date"].max() - pd.DateOffset(months=months - 1)
    df = df[df["rent_approval_date"] >= cutoff]
    # HDB towns largely share names with planning areas. Kallang/Whampoa is the
    # documented exception and is not split without block-level geocoding.
    town_map = {"KALLANG/WHAMPOA": "Kallang"}
    df["planning_area"] = df["town"].map(town_map).fillna(df["town"].str.title())
    out = df.groupby("planning_area", as_index=False).agg(
        hdb_monthly_rent=("monthly_rent", "mean"),
        hdb_contract_count=("monthly_rent", "count"),
        hdb_latest_month=("rent_approval_date", "max"),
    )
    return out


def ura_private_rents(boundaries: list, areas: pd.DataFrame) -> pd.DataFrame:
    access_key = os.getenv("URA_ACCESS_KEY")
    if not access_key:
        return pd.DataFrame(columns=["planning_area", "condo_monthly_rent", "house_monthly_rent",
                                     "condo_contract_count", "house_contract_count"])
    token = os.getenv("URA_TOKEN") or _get(
        "https://eservice.ura.gov.sg/uraDataService/insertNewToken/v1",
        headers={"AccessKey": access_key},
    ).json()["Result"]
    records = _get(
        "https://eservice.ura.gov.sg/uraDataService/invokeUraDS/v1",
        params={"service": "PMI_Resi_Rental"},
        headers={"AccessKey": access_key, "Token": token},
    ).json()["Result"]
    to_ll = Transformer.from_crs(3414, 4326, always_xy=True)
    tree = STRtree(boundaries)
    rows = []
    for project in records:
        lon, lat = to_ll.transform(float(project["x"]), float(project["y"]))
        indices = tree.query(Point(lon, lat), predicate="within")
        if not len(indices):
            continue
        area = areas.iloc[int(indices[0])]["planning_area"]
        for rental in project.get("rental", []):
            ptype = rental.get("propertyType", "")
            group = "condo" if ptype in {"Non-landed Properties", "Executive Condominium"} else "house"
            rows.append({"planning_area": area, "group": group, "rent": float(rental["rent"])})
    if not rows:
        return pd.DataFrame()
    rent = pd.DataFrame(rows)
    means = rent.pivot_table(index="planning_area", columns="group", values="rent", aggfunc="mean")
    counts = rent.pivot_table(index="planning_area", columns="group", values="rent", aggfunc="count")
    means.columns = [f"{c}_monthly_rent" for c in means.columns]
    counts.columns = [f"{c}_contract_count" for c in counts.columns]
    return means.join(counts).reset_index()


def propertyguru_asking_rents(boundaries: list, areas: pd.DataFrame) -> pd.DataFrame:
    """Aggregate an authorised PropertyGuru listing export when supplied.

    Expected file: data/raw/propertyguru_listings.csv. Required columns are
    listing_id, property_type, monthly_rent, latitude, longitude, whole_unit,
    listing_url and collected_at. `property_type` is condo or house.
    """
    path = RAW / "propertyguru_listings.csv"
    output_columns = [
        "planning_area", "propertyguru_condo_asking_rent_mean",
        "propertyguru_condo_asking_rent_median", "propertyguru_condo_listing_count",
        "propertyguru_house_asking_rent_mean", "propertyguru_house_asking_rent_median",
        "propertyguru_house_listing_count", "propertyguru_collected_at",
    ]
    if not path.exists():
        return pd.DataFrame(columns=output_columns)
    listings = pd.read_csv(path)
    required = {
        "listing_id", "property_type", "monthly_rent", "latitude", "longitude",
        "whole_unit", "listing_url", "collected_at",
    }
    missing = required - set(listings.columns)
    if missing:
        raise ValueError(f"PropertyGuru export is missing columns: {sorted(missing)}")
    listings["property_type"] = listings["property_type"].str.lower().str.strip()
    listings["whole_unit"] = listings["whole_unit"].astype(str).str.lower().isin({"1", "true", "yes"})
    listings["monthly_rent"] = pd.to_numeric(listings["monthly_rent"], errors="coerce")
    listings = listings[
        listings["whole_unit"]
        & listings["property_type"].isin(["condo", "house"])
        & listings["monthly_rent"].gt(0)
    ].drop_duplicates("listing_id", keep="last")
    tree = STRtree(boundaries)
    assigned = []
    for row in listings.to_dict("records"):
        indices = tree.query(Point(float(row["longitude"]), float(row["latitude"])), predicate="within")
        if len(indices):
            row["planning_area"] = areas.iloc[int(indices[0])]["planning_area"]
            assigned.append(row)
    if not assigned:
        return pd.DataFrame(columns=output_columns)
    frame = pd.DataFrame(assigned)
    grouped = frame.groupby(["planning_area", "property_type"])["monthly_rent"].agg(
        mean="mean", median="median", count="count"
    )
    wide = grouped.unstack("property_type")
    wide.columns = [f"propertyguru_{ptype}_asking_rent_{metric}" if metric != "count"
                    else f"propertyguru_{ptype}_listing_count"
                    for metric, ptype in wide.columns]
    dates = frame.groupby("planning_area")["collected_at"].max().rename("propertyguru_collected_at")
    return wide.join(dates).reset_index()


def overpass_pois() -> pd.DataFrame:
    parts = []
    endpoints = [
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass-api.de/api/interpreter",
    ]
    for category, filters in OSM_FILTERS.items():
        clauses = "".join(
            f'nwr["{key}"="{value}"](1.13,103.59,1.48,104.10);' for key, value in filters
        )
        query = f"[out:json][timeout:180];({clauses});out center tags;"
        last_error = None
        for endpoint in endpoints:
            try:
                payload = _get(endpoint, params={"data": query}).json()
                break
            except requests.RequestException as error:
                last_error = error
        else:
            raise RuntimeError(f"All Overpass endpoints failed: {last_error}")
        for item in payload["elements"]:
            lat = item.get("lat", item.get("center", {}).get("lat"))
            lon = item.get("lon", item.get("center", {}).get("lon"))
            if lat is None or lon is None:
                continue
            tags = item.get("tags", {})
            parts.append({
                "poi_id": f'osm:{item["type"]}:{item["id"]}', "category": category,
                "name": tags.get("name", "Unnamed"), "lat": lat, "lon": lon,
                "wheelchair": tags.get("wheelchair"), "source": "OpenStreetMap",
                "source_updated": date.today().isoformat(),
            })
        time.sleep(1)
    return pd.DataFrame(parts).drop_duplicates(["poi_id", "category"])


def haversine_km(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    dp, dl = np.radians(lat2 - lat1), np.radians(lon2 - lon1)
    a = np.sin(dp / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(dl / 2) ** 2
    return 6371.0088 * 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))


def attach_distances(areas: pd.DataFrame, polygons: list, pois: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    # Assign each facility to the planning area containing it. This produces one
    # distance per real facility, not an artificial 55-area Cartesian product.
    tree = STRtree(polygons)
    centre_lookup = areas.set_index("planning_area")[["centre_lat", "centre_lon"]]
    rows = []
    for poi in pois.to_dict("records"):
        indices = tree.query(Point(float(poi["lon"]), float(poi["lat"])), predicate="within")
        if not len(indices):
            continue
        area = areas.iloc[int(indices[0])]["planning_area"]
        centre = centre_lookup.loc[area]
        poi["planning_area"] = area
        poi["distance_km"] = haversine_km(
            centre.centre_lat, centre.centre_lon, float(poi["lat"]), float(poi["lon"])
        )
        rows.append(poi)
    distances = pd.DataFrame(rows)
    if distances.empty:
        return distances, areas[["planning_area"]].copy()
    nearest = distances.loc[distances.groupby(["planning_area", "category"])["distance_km"].idxmin()]
    wide = nearest.pivot(index="planning_area", columns="category", values="distance_km")
    wide.columns = [f"{c}_distance_km" for c in wide.columns]
    counts = distances.groupby(["planning_area", "category"])["poi_id"].count().unstack(fill_value=0)
    counts.columns = [f"{c}_count" for c in counts.columns]
    wheelchair_known = distances[distances["wheelchair"].isin(["yes", "no", "limited"])]
    accessibility = wheelchair_known.groupby("planning_area")["wheelchair"].agg(
        wheelchair_verified_count="count",
        wheelchair_accessibility_score=lambda values: (values == "yes").mean(),
    )
    summary = wide.join(counts).join(accessibility).reset_index()
    return distances, summary


def build(fetch_pois: bool = True) -> Path:
    RAW.mkdir(parents=True, exist_ok=True)
    PROCESSED.mkdir(parents=True, exist_ok=True)
    boundary_file = download_dataset(BOUNDARY_DATASET, RAW / "planning_areas.geojson")
    areas, polygons = planning_areas(boundary_file)
    areas["cbd_distance_km"] = haversine_km(
        areas.centre_lat, areas.centre_lon, CBD["lat"], CBD["lon"]
    )
    result = areas.merge(hdb_rents(), on="planning_area", how="left")
    result = result.merge(ura_private_rents(polygons, areas), on="planning_area", how="left")
    result = result.merge(propertyguru_asking_rents(polygons, areas), on="planning_area", how="left")
    poi_file = RAW / "pois.csv"
    if fetch_pois:
        overpass_pois().to_csv(poi_file, index=False)
    if poi_file.exists():
        all_distances, amenity_summary = attach_distances(areas, polygons, pd.read_csv(poi_file))
        all_distances.to_csv(PROCESSED / "all_centre_to_poi_distances.csv", index=False)
        result = result.merge(amenity_summary, on="planning_area", how="left")
    result["data_generated_at"] = pd.Timestamp.now(tz="Asia/Singapore").isoformat()
    output = PROCESSED / "planning_area_features.csv"
    result.to_csv(output, index=False)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-pois", action="store_true", help="Reuse data/raw/pois.csv")
    args = parser.parse_args()
    print(build(fetch_pois=not args.skip_pois))
