import argparse

from src.config import PROCESSED
from src.recommender import AreaRecommender, RecommendationRequest


def main():
    parser = argparse.ArgumentParser(description="Recommend Singapore planning areas")
    parser.add_argument("--housing", choices=["hdb", "condo", "house"], required=True)
    parser.add_argument("--budget", type=float, required=True)
    parser.add_argument("--criteria", nargs="+", required=True,
                        help="e.g. childcare healthcare mrt_stations cbd")
    parser.add_argument("--top", type=int, default=3)
    args = parser.parse_args()
    model = AreaRecommender(PROCESSED / "planning_area_complete.csv")
    result = model.recommend(RecommendationRequest(
        housing_type=args.housing,
        maximum_monthly_rent=args.budget,
        criteria=tuple(args.criteria),
        top_n=args.top,
    ))
    print(result.to_string(index=False) if len(result) else "No area meets all requirements.")


if __name__ == "__main__":
    main()
